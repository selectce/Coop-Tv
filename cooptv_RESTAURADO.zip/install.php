<?php
/**
 * SignageTV — Instalador
 * Acesse: http://seusite.com/signage/install.php
 * DELETE este arquivo após instalar!
 */

$step  = (int)($_POST['step'] ?? 1);
$error = '';
$done  = false;

if ($step === 2 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $host   = trim($_POST['db_host']   ?? 'localhost');
    $name   = trim($_POST['db_name']   ?? '');
    $user   = trim($_POST['db_user']   ?? '');
    $pass   = trim($_POST['db_pass']   ?? '');
    $admin  = trim($_POST['admin_user']?? 'admin');
    $apass  = trim($_POST['admin_pass']?? '');
    $url    = rtrim(trim($_POST['base_url'] ?? ''), '/');

    try {
        // Test connection
        $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

        // Create DB
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `$name`");

        // Create all tables one by one (safe, no file parsing)
        $tables = [
            "CREATE TABLE IF NOT EXISTS users (
                id INT PRIMARY KEY AUTO_INCREMENT,
                username VARCHAR(100) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS stores (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(150) NOT NULL,
                slug VARCHAR(100) NOT NULL UNIQUE,
                type ENUM('own','franchise') DEFAULT 'own',
                orientation ENUM('landscape','portrait') DEFAULT 'landscape',
                playback_order ENUM('sequential','random') DEFAULT 'sequential',
                single_video_mode TINYINT(1) DEFAULT 0,
                single_video_id INT DEFAULT NULL,
                show_controls TINYINT(1) DEFAULT 1,
                active TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS media (
                id INT PRIMARY KEY AUTO_INCREMENT,
                filename VARCHAR(255) NOT NULL,
                original_name VARCHAR(255) NOT NULL,
                type ENUM('video','image') NOT NULL,
                mime_type VARCHAR(100),
                size BIGINT DEFAULT 0,
                duration DECIMAL(10,2) DEFAULT 0,
                width INT DEFAULT 0,
                height INT DEFAULT 0,
                thumb VARCHAR(255) DEFAULT NULL,
                uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS timeline_items (
                id INT PRIMARY KEY AUTO_INCREMENT,
                store_id INT NOT NULL,
                media_id INT NOT NULL,
                position INT NOT NULL DEFAULT 0,
                duration DECIMAL(10,2) DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
                FOREIGN KEY (media_id) REFERENCES media(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS playback_logs (
                id INT PRIMARY KEY AUTO_INCREMENT,
                store_id INT NOT NULL,
                media_id INT NOT NULL,
                played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
                FOREIGN KEY (media_id) REFERENCES media(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE INDEX IF NOT EXISTS idx_logs_store ON playback_logs(store_id)",
            "CREATE INDEX IF NOT EXISTS idx_logs_media ON playback_logs(media_id)",
            "CREATE INDEX IF NOT EXISTS idx_logs_date  ON playback_logs(played_at)",
            "CREATE INDEX IF NOT EXISTS idx_timeline_store ON timeline_items(store_id, position)",

            "INSERT IGNORE INTO stores (name, slug, type) VALUES
                ('Loja 01 - Centro',  'loja-01',     'own'),
                ('Loja 02 - Norte',   'loja-02',     'own'),
                ('Loja 03 - Sul',     'loja-03',     'own'),
                ('Loja 04 - Leste',   'loja-04',     'own'),
                ('Loja 05 - Oeste',   'loja-05',     'own'),
                ('Franquia 01',       'franquia-01', 'franchise'),
                ('Franquia 02',       'franquia-02', 'franchise'),
                ('Franquia 03',       'franquia-03', 'franchise'),
                ('Franquia 04',       'franquia-04', 'franchise'),
                ('Franquia 05',       'franquia-05', 'franchise')",
        ];

        foreach ($tables as $sql) {
            $pdo->exec($sql);
        }

        // Create admin user
        $hash = password_hash($apass, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?) ON DUPLICATE KEY UPDATE password = VALUES(password)");
        $stmt->execute([$admin, $hash]);

        // Write config.php
        $configContent = <<<PHP
<?php
define('DB_HOST',    '$host');
define('DB_NAME',    '$name');
define('DB_USER',    '$user');
define('DB_PASS',    '$pass');
define('DB_CHARSET', 'utf8mb4');

define('BASE_URL',    '$url');
define('UPLOAD_PATH',  __DIR__ . '/uploads');
define('MAX_UPLOAD_SIZE', 0);

define('APP_VERSION', '1.0.0');
define('APP_NAME',    'SignageTV');

date_default_timezone_set('America/Sao_Paulo');
ini_set('session.gc_maxlifetime', 86400);
session_set_cookie_params(86400);
PHP;
        file_put_contents(__DIR__ . '/config.php', $configContent);

        // Create upload dirs
        @mkdir(__DIR__ . '/uploads/videos', 0755, true);
        @mkdir(__DIR__ . '/uploads/images', 0755, true);
        @mkdir(__DIR__ . '/uploads/thumbs', 0755, true);

        $done = true;

        // Auto-deletar install.php por segurança
        @unlink(__FILE__);

    } catch (Exception $e) {
        $error = $e->getMessage();
        $step  = 1;
    }
}

// Guess base URL
$guessUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on' ? 'https' : 'http')
          . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
          . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Instalação — SignageTV</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,sans-serif;background:#0f1117;color:#e2e8f0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem}
.box{background:#1a1d2e;border:1px solid #2e3250;border-radius:16px;padding:2.5rem;max-width:520px;width:100%}
h1{font-size:1.5rem;margin-bottom:.3rem;display:flex;align-items:center;gap:.6rem}
.sub{color:#64748b;margin-bottom:2rem;font-size:.88rem}
label{display:block;font-size:.78rem;font-weight:600;color:#64748b;text-transform:uppercase;margin-bottom:.3rem;margin-top:.9rem}
input{width:100%;background:#232640;border:1px solid #2e3250;border-radius:8px;color:#e2e8f0;padding:.6rem .9rem;font-size:.9rem}
input:focus{outline:none;border-color:#6366f1}
.btn{display:block;width:100%;margin-top:1.5rem;padding:.75rem;background:#6366f1;border:none;border-radius:8px;color:#fff;font-size:1rem;font-weight:600;cursor:pointer}
.btn:hover{background:#4f46e5}
.error{background:#ef444420;border:1px solid #ef444460;color:#ef4444;padding:.8rem 1rem;border-radius:8px;margin-bottom:1rem;font-size:.85rem}
.success{background:#22c55e20;border:1px solid #22c55e40;color:#22c55e;padding:1rem;border-radius:8px;font-size:.9rem;line-height:1.7}
.success a{color:#22c55e;font-weight:600}
.warn{background:#f9731620;border:1px solid #f9731640;color:#f97316;padding:.7rem 1rem;border-radius:8px;font-size:.82rem;margin-top:1.2rem}
hr{border:none;border-top:1px solid #2e3250;margin:1.2rem 0}
</style>
</head>
<body>
<div class="box">
  <div style="text-align:center;margin-bottom:2rem;padding-bottom:1.5rem;border-bottom:1px solid #2e3250">
    <img src="coop-logo.png" alt="Coop Digital Studio" style="max-width:220px;width:100%;filter:invert(1)">
  </div>

  <?php if ($done): ?>
    <div class="success">
      ✅ <strong>Instalação concluída!</strong><br>
      Usuário: <strong><?= htmlspecialchars($admin) ?></strong><br>
      Senha: a que você definiu<br><br>
      👉 <a href="<?= htmlspecialchars($url) ?>/login.php">Acessar o painel</a>
    </div>
    <div class="warn">⚠ <strong>Importante:</strong> Delete o arquivo <code>install.php</code> do servidor agora!</div>
  <?php else: ?>
    <?php if ($error): ?>
      <div class="error">❌ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="step" value="2">

      <hr><strong>Banco de Dados</strong>
      <label>Host do MySQL</label>
      <input name="db_host" value="localhost" required>
      <label>Nome do Banco</label>
      <input name="db_name" placeholder="signage_tv" required>
      <label>Usuário MySQL</label>
      <input name="db_user" required>
      <label>Senha MySQL</label>
      <input name="db_pass" type="password">

      <hr><strong>Administrador</strong>
      <label>Usuário Admin</label>
      <input name="admin_user" value="admin" required>
      <label>Senha Admin</label>
      <input name="admin_pass" type="password" required minlength="6">

      <hr><strong>URL do Sistema</strong>
      <label>URL Base (sem barra final)</label>
      <input name="base_url" value="<?= htmlspecialchars($guessUrl) ?>" required>

      <button class="btn" type="submit">🚀 Instalar</button>
    </form>
  <?php endif; ?>
</div>
</body>
</html>
