<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$slug  = trim($_GET['store'] ?? '');
$store = $slug ? dbFetch("SELECT * FROM stores WHERE slug=?", [$slug]) : null;

if (!$store) {
    http_response_code(404);
    die('<!DOCTYPE html><html><body style="background:#000;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;text-align:center"><div><div style="font-size:4rem">📺</div><h2>Ponto não encontrado</h2></div></body></html>');
}

$items = dbFetchAll("
    SELECT t.id, t.media_id, t.position,
           COALESCE(t.duration, m.duration) as duration,
           m.original_name, m.type, m.filename
    FROM timeline_items t
    JOIN media m ON t.media_id = m.id
    WHERE t.store_id = ?
    ORDER BY t.position
", [$store['id']]);

$singleVideo = null;
if ($store['single_video_mode'] && $store['single_video_id'])
    $singleVideo = dbFetch("SELECT * FROM media WHERE id=?", [$store['single_video_id']]);

$baseUrl  = BASE_URL . '/uploads/';
$playlist = [];
if ($singleVideo) {
    $playlist[] = ['media_id'=>(int)$singleVideo['id'],'type'=>$singleVideo['type'],
        'url'=>$baseUrl.'videos/'.$singleVideo['filename'],'duration'=>(float)$singleVideo['duration'],'name'=>$singleVideo['original_name']];
} else {
    foreach ($items as $item)
        $playlist[] = ['media_id'=>(int)$item['media_id'],'type'=>$item['type'],
            'url'=>$baseUrl.($item['type']==='video'?'videos':'images').'/'.$item['filename'],
            'duration'=>(float)$item['duration'],'name'=>$item['original_name']];
}
if ($store['playback_order']==='random') shuffle($playlist);
$portrait = $store['orientation']==='portrait';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<title><?= sanitize($store['name']) ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:100%;height:100%;background:#000;overflow:hidden;font-family:sans-serif}

/* ---- Player ---- */
#player{position:fixed;inset:0;background:#000;overflow:hidden}

/*
  VÍDEO: cobre 100% sem barras pretas
  Técnica: width+height 100%, object-fit:cover garante cobertura total.
  Fallback para TVs antigas (LG webOS < 4, Tizen < 5) sem object-fit:
  usa min-width/min-height + translate para centralizar e cobrir.
*/
#videoEl{
  position:absolute;
  top:0;left:0;
  width:100%;height:100%;
  display:none;
  background:#000;
  /* object-fit para browsers modernos */
  object-fit:cover;
  object-position:center center;
}
/* Fallback para TVs sem object-fit */
@supports not (object-fit:cover){
  #videoEl{
    width:auto;height:auto;
    min-width:100%;min-height:100%;
    top:50%;left:50%;
    transform:translate(-50%,-50%);
  }
}
#imageEl{
  position:absolute;
  top:0;left:0;
  width:100%;height:100%;
  object-fit:cover;
  object-position:center center;
  display:none;
  background:#000;
}
#videoEl.on{display:block}
#imageEl.on{display:block}

/* ---- Modo retrato (TV girada 90°) ---- */
<?php if ($portrait): ?>
#videoEl,#imageEl{
  width:100vh !important;
  height:100vw !important;
  top:50% !important;
  left:50% !important;
  transform:translate(-50%,-50%) rotate(90deg) !important;
  min-width:unset;min-height:unset;
  object-fit:cover;
}
<?php endif; ?>

/* ---- Loading ---- */
#load{position:fixed;inset:0;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:200;transition:opacity .5s}
#load.out{opacity:0;pointer-events:none}
.spin{width:44px;height:44px;border:3px solid rgba(255,255,255,.1);border-top-color:rgba(255,255,255,.6);border-radius:50%;animation:sp .8s linear infinite;margin-bottom:14px}
@keyframes sp{to{transform:rotate(360deg)}}
.ltxt{color:rgba(255,255,255,.4);font-size:13px}

/* ---- Vazio ---- */
#empty{position:fixed;inset:0;display:none;flex-direction:column;align-items:center;justify-content:center;color:rgba(255,255,255,.3);gap:14px}
#empty .ico{font-size:56px}

/* ---- Controles ---- */
#ctrl{
  position:fixed;bottom:0;left:0;right:0;
  background:linear-gradient(transparent,rgba(0,0,0,.9));
  padding:44px 28px 24px;
  display:flex;align-items:center;justify-content:space-between;
  transform:translateY(100%);transition:transform .3s ease;z-index:50;
}
#ctrl.show{transform:translateY(0)}
.cbtns{display:flex;gap:10px;flex-wrap:wrap}
.cbtn{
  background:rgba(255,255,255,.15);border:2px solid rgba(255,255,255,.28);
  color:#fff;padding:11px 20px;border-radius:12px;font-size:14px;
  cursor:pointer;display:flex;align-items:center;gap:7px;
  backdrop-filter:blur(8px);
  transition:background .2s,border-color .2s;
  -webkit-tap-highlight-color:transparent;
}
.cbtn:hover,.cbtn.foc{background:rgba(255,255,255,.28);border-color:#fff}
.cbtn.foc{outline:3px solid #6366f1}
.cinfo{color:rgba(255,255,255,.6);font-size:12px;text-align:right;line-height:1.7}
.cstore{font-size:14px;color:#fff;font-weight:600}

/* ---- Progresso ---- */
#prog{position:fixed;bottom:0;left:0;height:3px;background:linear-gradient(90deg,#6366f1,#a855f7);width:0%;z-index:60}

/* ---- Now playing ---- */
#np{
  position:fixed;top:16px;right:16px;
  background:rgba(0,0,0,.5);color:rgba(255,255,255,.5);
  padding:4px 13px;border-radius:999px;font-size:12px;
  backdrop-filter:blur(6px);opacity:0;transition:opacity .3s;z-index:50;
  max-width:38%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
}
#np.show{opacity:1}

/* ---- Offline ---- */
#offl{
  position:fixed;top:14px;left:50%;transform:translateX(-50%);
  background:rgba(239,68,68,.85);color:#fff;padding:6px 18px;
  border-radius:999px;font-size:13px;display:none;z-index:300;
}
</style>
</head>
<body>

<div id="load"><div class="spin"></div><div class="ltxt">Carregando...</div></div>

<div id="empty">
  <div class="ico">📺</div>
  <div>Nenhuma mídia na programação</div>
</div>

<div id="player">
  <video id="videoEl" playsinline muted autoplay preload="auto"></video>
  <img   id="imageEl" alt="">
</div>

<div id="np"></div>

<div id="ctrl">
  <div class="cbtns" id="cbtns">
    <button class="cbtn" onclick="togglePlay()"><span id="pIcon">⏸</span><span id="pLbl">Pausar</span></button>
    <button class="cbtn" onclick="go(idx+1)">⏭ Próximo</button>
    <button class="cbtn" onclick="location.reload()">🔄 Atualizar</button>
    <button class="cbtn" onclick="toggleFs()">⛶ Tela Cheia</button>
  </div>
  <div class="cinfo">
    <div class="cstore"><?= sanitize($store['name']) ?></div>
    <div id="cpos"></div>
  </div>
</div>

<div id="prog"></div>
<div id="offl">⚠ Sem conexão</div>

<script>
var CFG={storeId:<?=(int)$store['id']?>,baseUrl:<?=json_encode(BASE_URL)?>,showCtrl:<?=$store['show_controls']?'true':'false'?>,order:<?=json_encode($store['playback_order'])?>,reload:300};
var pl=<?=json_encode($playlist)?>;
var idx=0,paused=false,imgT=null,ctT=null,pRaf=null,pDur=0,pFrom=0;

// Flag crítica: impede evento 'error' de disparar nextItem durante troca de src
var switching=false;

var V=document.getElementById('videoEl'),
    I=document.getElementById('imageEl'),
    CT=document.getElementById('ctrl'),
    NP=document.getElementById('np'),
    PB=document.getElementById('prog'),
    LS=document.getElementById('load'),
    EM=document.getElementById('empty'),
    CP=document.getElementById('cpos'),
    PI=document.getElementById('pIcon'),
    PL=document.getElementById('pLbl');
var cbs=[];

window.addEventListener('load',function(){
  cbs=Array.from(document.querySelectorAll('.cbtn'));
  if(!pl.length){LS.classList.add('out');EM.style.display='flex';return;}
  tryFs();
  setTimeout(function(){LS.classList.add('out');go(0);},600);
  setInterval(refreshPl,CFG.reload*1000);
});

function go(i){
  idx=((i%pl.length)+pl.length)%pl.length;
  var it=pl[idx];
  CP.textContent=(idx+1)+'/'+pl.length+' — '+it.name;
  showNP(it.name);
  logPlay(it.media_id);
  clearImgT();
  cancelAnimationFrame(pRaf);
  PB.style.width='0%';
  pFrom=0; pDur=it.duration||10;

  if(it.type==='video'){
    I.classList.remove('on'); I.src='';
    V.classList.add('on');
    // --- FIX: switching=true impede error handler de chamar next ---
    switching=true;
    V.pause();
    V.src=it.url;
    V.load();
    switching=false;
    // ---------------------------------------------------------------
    var p=V.play();
    if(p!==undefined) p.catch(function(){V.muted=true;V.play().catch(function(){setTimeout(function(){go(idx+1);},2000);});});
    animP(pDur);
  } else {
    V.pause(); V.classList.remove('on');
    I.src=it.url; I.classList.add('on');
    animP(pDur);
    imgT=setTimeout(function(){if(!paused)go(idx+1);},pDur*1000);
  }
}

V.addEventListener('ended',function(){if(!paused)go(idx+1);});
V.addEventListener('error',function(){
  if(switching)return; // Ignora erro durante troca de src
  console.warn('video error');
  setTimeout(function(){go(idx+1);},1500);
});
V.addEventListener('stalled',function(){
  setTimeout(function(){if(!V.ended&&!paused)V.play().catch(function(){});},3000);
});

function togglePlay(){
  paused=!paused;
  if(paused){
    V.pause();clearImgT();cancelAnimationFrame(pRaf);
    PI.textContent='▶';PL.textContent='Continuar';
  } else {
    if(pl[idx]&&pl[idx].type==='video')V.play().catch(function(){});
    else{var rem=pDur*(1-parseFloat(PB.style.width)/100);imgT=setTimeout(function(){if(!paused)go(idx+1);},rem*1000);}
    animP(pDur*(1-pFrom/100));
    PI.textContent='⏸';PL.textContent='Pausar';
  }
}

function animP(dur){
  cancelAnimationFrame(pRaf);
  pFrom=parseFloat(PB.style.width)||0;
  var st=performance.now();
  function tick(now){
    if(paused)return;
    var pct=Math.min(pFrom+((now-st)/1000/dur)*(100-pFrom),100);
    PB.style.width=pct+'%';
    if(pct<100)pRaf=requestAnimationFrame(tick);
  }
  pRaf=requestAnimationFrame(tick);
}

function clearImgT(){if(imgT){clearTimeout(imgT);imgT=null;}}

function showCtrl(){
  if(!CFG.showCtrl)return;
  CT.classList.add('show');clearTimeout(ctT);
  ctT=setTimeout(hideCtrl,5000);
}
function hideCtrl(){CT.classList.remove('show');ctFoc=0;cbs.forEach(function(b){b.classList.remove('foc');});}
var ctFoc=0;

function showNP(n){
  NP.textContent='▶ '+n;NP.classList.add('show');
  setTimeout(function(){NP.classList.remove('show');},3000);
}

function tryFs(){
  var el=document.documentElement;
  var fn=el.requestFullscreen||el.webkitRequestFullscreen||el.mozRequestFullScreen||el.msRequestFullscreen;
  if(fn)fn.call(el).catch(function(){});
}
function toggleFs(){
  if(document.fullscreenElement||document.webkitFullscreenElement){
    var fn=document.exitFullscreen||document.webkitExitFullscreen;if(fn)fn.call(document);
  } else tryFs();
}

function refreshPl(){
  fetch(CFG.baseUrl+'/api/timeline.php?store='+CFG.storeId)
  .then(function(r){return r.json();})
  .then(function(d){
    if(!d.items||!d.items.length)return;
    var nl=d.items.map(function(i){return{media_id:i.media_id,type:i.type,url:i.url,duration:i.duration,name:i.original_name};});
    if(d.store&&d.store.playback_order==='random')shuffle(nl);
    pl=nl;
  }).catch(function(){});
}

function logPlay(mid){
  var b=JSON.stringify({store_id:CFG.storeId,media_id:mid});
  if(navigator.sendBeacon)navigator.sendBeacon(CFG.baseUrl+'/api/log.php',b);
  else fetch(CFG.baseUrl+'/api/log.php',{method:'POST',headers:{'Content-Type':'application/json'},body:b,keepalive:true}).catch(function(){});
}

var KM={'ArrowLeft':'prev','ArrowRight':'next','Enter':'ok',' ':'ok','MediaPlayPause':'pp','MediaPlay':'play','MediaPause':'pause','MediaTrackNext':'next','MediaTrackPrevious':'prev','Escape':'back','Backspace':'back','F5':'reload',179:'pp',176:'next',177:'prev',403:'red',404:'green',405:'yellow',406:'blue',461:'back'};
document.addEventListener('keydown',function(e){
  var a=KM[e.key]||KM[e.keyCode];
  showCtrl();document.body.style.cursor='default';
  if(!a)return;e.preventDefault();
  var vis=CT.classList.contains('show');
  if(a==='prev'){vis?(ctFoc=Math.max(0,ctFoc-1),updF()):go(idx-1);}
  else if(a==='next'){vis?(ctFoc=Math.min(cbs.length-1,ctFoc+1),updF()):go(idx+1);}
  else if(a==='ok'){vis?cbs[ctFoc]&&cbs[ctFoc].click():togglePlay();}
  else if(a==='pp')togglePlay();
  else if(a==='play'&&paused)togglePlay();
  else if(a==='pause'&&!paused)togglePlay();
  else if(a==='reload')location.reload();
  else if(a==='back')hideCtrl();
  else if(a==='red')go(idx-1);
  else if(a==='green')togglePlay();
  else if(a==='yellow')go(idx+1);
  else if(a==='blue')location.reload();
});
document.addEventListener('mousemove',function(){document.body.style.cursor='default';showCtrl();clearTimeout(document._cm);document._cm=setTimeout(function(){document.body.style.cursor='none';},3000);});
function updF(){cbs.forEach(function(b,i){b.classList.toggle('foc',i===ctFoc);});}

window.addEventListener('offline',function(){document.getElementById('offl').style.display='block';});
window.addEventListener('online',function(){document.getElementById('offl').style.display='none';refreshPl();});

function totalDur(){return pl.reduce(function(s,i){return s+(i.duration||0);},0);}
function fmtDur(s){var h=Math.floor(s/3600),m=Math.floor((s%3600)/60),sc=Math.floor(s%60);return h>0?h+':'+pad(m)+':'+pad(sc):m+':'+pad(sc);}
function pad(n){return n<10?'0'+n:''+n;}
function shuffle(a){for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t;}}
</script>
</body>
</html>
