<?php
$currentPage = 'dashboard';
$pageTitle   = 'Dashboard';
require_once __DIR__ . '/../includes/header.php';

// Stats
$totalStores  = dbFetch("SELECT COUNT(*) as c FROM stores")['c'];
$ownStores    = dbFetch("SELECT COUNT(*) as c FROM stores WHERE type='own'")['c'];
$franchises   = dbFetch("SELECT COUNT(*) as c FROM stores WHERE type='franchise'")['c'];
$totalMedia   = dbFetch("SELECT COUNT(*) as c FROM media")['c'];
$totalVideos  = dbFetch("SELECT COUNT(*) as c FROM media WHERE type='video'")['c'];
$totalImages  = dbFetch("SELECT COUNT(*) as c FROM media WHERE type='image'")['c'];
$totalSize    = dbFetch("SELECT COALESCE(SUM(size),0) as s FROM media")['s'];
$todayPlays   = dbFetch("SELECT COUNT(*) as c FROM playback_logs WHERE DATE(played_at)=CURDATE()")['c'];
$weekPlays    = dbFetch("SELECT COUNT(*) as c FROM playback_logs WHERE played_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")['c'];

// Top 5 vídeos hoje
$topToday = dbFetchAll("
    SELECT m.original_name, COUNT(*) as plays
    FROM playback_logs l
    JOIN media m ON l.media_id = m.id
    WHERE DATE(l.played_at) = CURDATE()
    GROUP BY l.media_id
    ORDER BY plays DESC
    LIMIT 5
");

// Plays por ponto hoje
$storeStats = dbFetchAll("
    SELECT s.name, s.type, COUNT(l.id) as plays
    FROM stores s
    LEFT JOIN playback_logs l ON s.id = l.store_id AND DATE(l.played_at) = CURDATE()
    GROUP BY s.id
    ORDER BY plays DESC
");

// Stores com timeline
$storesWithTimeline = dbFetchAll("
    SELECT s.*, COUNT(t.id) as items,
           COALESCE(SUM(COALESCE(t.duration, m.duration)),0) as total_dur
    FROM stores s
    LEFT JOIN timeline_items t ON s.id = t.store_id
    LEFT JOIN media m ON t.media_id = m.id
    GROUP BY s.id
    ORDER BY s.type, s.name
");
?>

<!-- Stats Cards -->
<div class="stats-grid">
  <div class="stat-card blue">
    <div class="stat-icon"><i class="fa-solid fa-store"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= $totalStores ?></div>
      <div class="stat-label">Pontos Totais</div>
      <div class="stat-sub"><?= $ownStores ?> próprias · <?= $franchises ?> franquias</div>
    </div>
  </div>
  <div class="stat-card purple">
    <div class="stat-icon"><i class="fa-solid fa-photo-film"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= $totalMedia ?></div>
      <div class="stat-label">Mídias</div>
      <div class="stat-sub"><?= $totalVideos ?> vídeos · <?= $totalImages ?> imagens</div>
    </div>
  </div>
  <div class="stat-card green">
    <div class="stat-icon"><i class="fa-solid fa-play"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= number_format($todayPlays) ?></div>
      <div class="stat-label">Reproduções Hoje</div>
      <div class="stat-sub"><?= number_format($weekPlays) ?> nos últimos 7 dias</div>
    </div>
  </div>
  <div class="stat-card orange">
    <div class="stat-icon"><i class="fa-solid fa-hard-drive"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= formatBytes((int)$totalSize) ?></div>
      <div class="stat-label">Armazenamento</div>
      <div class="stat-sub">total de uploads</div>
    </div>
  </div>
</div>

<div class="dash-grid">
  <!-- Lojas -->
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-store"></i> Status dos Pontos</h3>
      <a href="<?= BASE_URL ?>/admin/stores.php" class="btn btn-sm">Gerenciar</a>
    </div>
    <div class="card-body p0">
      <table class="table">
        <thead><tr><th>Loja</th><th>Tipo</th><th>Itens</th><th>Duração</th><th>Player</th></tr></thead>
        <tbody>
        <?php foreach ($storesWithTimeline as $s): ?>
        <tr>
          <td><strong><?= sanitize($s['name']) ?></strong></td>
          <td><span class="badge <?= $s['type']==='own'?'badge-blue':'badge-orange' ?>"><?= $s['type']==='own'?'Própria':'Franquia' ?></span></td>
          <td><?= $s['items'] ?> item(s)</td>
          <td><?= formatDuration((float)$s['total_dur']) ?></td>
          <td>
            <a href="<?= storeUrl($s) ?>" target="_blank" class="btn btn-sm btn-green" title="Abrir Player">
              <i class="fa-solid fa-tv"></i>
            </a>
            <a href="<?= BASE_URL ?>/admin/timeline.php?store=<?= $s['id'] ?>" class="btn btn-sm" title="Editar Timeline">
              <i class="fa-solid fa-film"></i>
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Top vídeos hoje -->
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-trophy"></i> Top Vídeos Hoje</h3>
      <a href="<?= BASE_URL ?>/admin/reports.php" class="btn btn-sm">Ver Relatórios</a>
    </div>
    <div class="card-body p0">
      <?php if (empty($topToday)): ?>
        <p class="empty-msg"><i class="fa-solid fa-info-circle"></i> Nenhuma reprodução hoje ainda.</p>
      <?php else: ?>
      <table class="table">
        <thead><tr><th>#</th><th>Mídia</th><th>Reproduções</th></tr></thead>
        <tbody>
        <?php foreach ($topToday as $i => $v): ?>
        <tr>
          <td><strong><?= $i+1 ?></strong></td>
          <td><?= sanitize($v['original_name']) ?></td>
          <td><span class="badge badge-green"><?= $v['plays'] ?>x</span></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>

    <!-- Plays por ponto -->
    <div class="card-header" style="margin-top:1rem">
      <h3><i class="fa-solid fa-chart-bar"></i> Reproduções por Ponto Hoje</h3>
    </div>
    <div class="card-body p0">
      <table class="table">
        <thead><tr><th>Loja</th><th>Tipo</th><th>Reproduções</th></tr></thead>
        <tbody>
        <?php foreach ($storeStats as $s): ?>
        <tr>
          <td><?= sanitize($s['name']) ?></td>
          <td><span class="badge <?= $s['type']==='own'?'badge-blue':'badge-orange' ?>"><?= $s['type']==='own'?'Própria':'Franquia' ?></span></td>
          <td><?= number_format($s['plays']) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
