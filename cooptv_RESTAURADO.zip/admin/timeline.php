<?php
$currentPage = 'timeline';
$pageTitle   = 'Editor de Timeline';
require_once __DIR__ . '/../includes/header.php';

// Load stores for selector
$stores  = dbFetchAll("SELECT id, name, type FROM stores ORDER BY type, name");
$storeId = (int)($_GET['store'] ?? ($stores[0]['id'] ?? 0));
$store   = $storeId ? dbFetch("SELECT * FROM stores WHERE id=?", [$storeId]) : null;

// Load media library
$mediaLib = dbFetchAll("SELECT * FROM media ORDER BY type, original_name");

// Load current timeline
$timeline = $storeId ? dbFetchAll("
    SELECT t.*, m.original_name, m.type as media_type, m.duration as orig_duration,
           m.filename, m.thumb, m.size
    FROM timeline_items t
    JOIN media m ON t.media_id = m.id
    WHERE t.store_id = ?
    ORDER BY t.position
", [$storeId]) : [];

$totalDuration = array_sum(array_map(fn($i) => (float)($i['duration'] ?? $i['orig_duration']), $timeline));
?>

<!-- Store Selector -->
<div class="timeline-header">
  <div class="store-selector-wrap">
    <label><i class="fa-solid fa-store"></i> Loja:</label>
    <select id="storeSelector" onchange="window.location='?store='+this.value">
      <?php foreach ($stores as $s): ?>
        <option value="<?= $s['id'] ?>" <?= $s['id']==$storeId?'selected':'' ?>>
          <?= sanitize($s['name']) ?> (<?= $s['type']==='own'?'Própria':'Franquia' ?>)
        </option>
      <?php endforeach; ?>
    </select>
  </div>
  <?php if ($store): ?>
  <div class="timeline-actions">
    <span class="badge badge-blue"><i class="fa-solid fa-clock"></i> Total: <strong id="totalDur"><?= formatDuration($totalDuration) ?></strong></span>
    <a href="<?= BASE_URL ?>/admin/settings.php?store=<?= $storeId ?>" class="btn btn-sm"><i class="fa-solid fa-gear"></i> Config</a>
    <a href="<?= storeUrl($store) ?>" target="_blank" class="btn btn-sm btn-green"><i class="fa-solid fa-tv"></i> Player</a>
  </div>
  <?php endif; ?>
</div>

<?php if (!$store): ?>
  <div class="alert alert-error">Selecione um ponto acima.</div>
  <?php require_once __DIR__.'/../includes/footer.php'; exit; ?>
<?php endif; ?>

<div class="timeline-layout">

  <!-- Left: Media Library -->
  <div class="card media-panel">
    <div class="card-header">
      <h3><i class="fa-solid fa-photo-film"></i> Mídias</h3>
    </div>
    <div class="card-body p0">
      <div class="media-search">
        <input type="text" placeholder="Buscar..." oninput="filterLib(this.value)">
      </div>
      <div class="media-lib" id="mediaLib">
        <?php foreach ($mediaLib as $m): ?>
        <div class="lib-item" data-name="<?= strtolower(sanitize($m['original_name'])) ?>"
             data-id="<?= $m['id'] ?>"
             data-type="<?= $m['type'] ?>"
             data-name-orig="<?= sanitize($m['original_name']) ?>"
             data-duration="<?= $m['duration'] ?>"
             data-filename="<?= sanitize($m['filename']) ?>"
             data-thumb="<?= sanitize($m['thumb'] ?? '') ?>"
             draggable="true"
             ondragstart="libDragStart(event)"
             ondblclick="addToTimeline(this)">
          <div class="lib-thumb">
            <?php
            $baseUrl = BASE_URL . '/uploads/';
            if ($m['type'] === 'video'):
                $tsrc = $m['thumb'] ? $baseUrl.'thumbs/'.$m['thumb'] : '';
            ?>
              <?php if ($tsrc): ?>
                <img src="<?= $tsrc ?>" alt="">
              <?php else: ?>
                <div class="lib-icon"><i class="fa-solid fa-film"></i></div>
              <?php endif; ?>
              <span class="lib-badge video">▶</span>
            <?php else: ?>
              <img src="<?= $baseUrl.'images/'.$m['filename'] ?>" alt="">
              <span class="lib-badge image">🖼</span>
            <?php endif; ?>
          </div>
          <div class="lib-info">
            <span class="lib-name"><?= sanitize($m['original_name']) ?></span>
            <span class="lib-dur"><?= $m['duration'] > 0 ? formatDuration((float)$m['duration']) : '—' ?></span>
          </div>
        </div>
        <?php endforeach; ?>
        <?php if (empty($mediaLib)): ?>
          <p class="empty-msg"><a href="<?= BASE_URL ?>/admin/media.php">Faça upload de mídias primeiro</a></p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Right: Timeline -->
  <div class="card timeline-panel">
    <div class="card-header">
      <h3><i class="fa-solid fa-film"></i> Timeline — <?= sanitize($store['name']) ?></h3>
      <div>
        <button class="btn btn-sm btn-red" onclick="clearTimeline()" <?= empty($timeline)?'disabled':'' ?>>
          <i class="fa-solid fa-trash"></i> Limpar
        </button>
        <button class="btn btn-sm btn-primary" id="saveBtn" onclick="saveTimeline()">
          <i class="fa-solid fa-save"></i> Salvar
        </button>
      </div>
    </div>

    <div class="timeline-info">
      <span><i class="fa-solid fa-list"></i> <span id="itemCount"><?= count($timeline) ?></span> item(s)</span>
      <span><i class="fa-solid fa-clock"></i> Duração total: <strong id="totalDurTl"><?= formatDuration($totalDuration) ?></strong></span>
      <span style="color:var(--muted);font-size:.8rem">Arraste para reordenar · Duplo clique na mídia para adicionar</span>
    </div>

    <!-- Drop zone -->
    <div id="timelineTrack" class="timeline-track"
         ondragover="trackDragOver(event)"
         ondrop="trackDrop(event)">

      <?php if (empty($timeline)): ?>
        <div class="tl-empty" id="tlEmpty">
          <i class="fa-solid fa-film"></i>
          <p>Arraste mídias aqui ou dê duplo clique nelas</p>
        </div>
      <?php endif; ?>

      <?php foreach ($timeline as $item): ?>
      <div class="tl-item" data-id="<?= $item['id'] ?>"
           data-media-id="<?= $item['media_id'] ?>"
           data-type="<?= $item['media_type'] ?>"
           data-duration="<?= $item['duration'] ?? $item['orig_duration'] ?>"
           data-orig-duration="<?= $item['orig_duration'] ?>"
           draggable="true"
           ondragstart="tlDragStart(event)">
        <div class="tl-handle"><i class="fa-solid fa-grip-vertical"></i></div>
        <div class="tl-thumb">
          <?php
          $baseUrl = BASE_URL . '/uploads/';
          if ($item['media_type'] === 'video'):
              $tsrc = $item['thumb'] ? $baseUrl.'thumbs/'.$item['thumb'] : '';
          ?>
            <?php if ($tsrc): ?><img src="<?= $tsrc ?>" alt="">
            <?php else: ?><div class="lib-icon"><i class="fa-solid fa-film"></i></div>
            <?php endif; ?>
          <?php else: ?>
            <img src="<?= $baseUrl.'images/'.$item['filename'] ?>" alt="">
          <?php endif; ?>
        </div>
        <div class="tl-info">
          <span class="tl-name"><?= sanitize($item['original_name']) ?></span>
          <span class="badge <?= $item['media_type']==='video'?'badge-purple':'badge-blue' ?>">
            <?= ucfirst($item['media_type']) ?>
          </span>
        </div>
        <div class="tl-duration">
          <label>Duração (s)</label>
          <input type="number" class="dur-input" min="1" step="0.5"
                 value="<?= round((float)($item['duration'] ?? $item['orig_duration']),1) ?>"
                 onchange="updateDuration(this)">
        </div>
        <button class="tl-remove" onclick="removeItem(this)" title="Remover">
          <i class="fa-solid fa-times"></i>
        </button>
      </div>
      <?php endforeach; ?>
    </div>

  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
<script>
const BASE_URL  = '<?= BASE_URL ?>';
const STORE_ID  = <?= $storeId ?>;
const BASE_MEDIA = BASE_URL + '/uploads/';
let   dragSource = null; // 'lib' or 'tl'
let   dragData   = null;

// ---- Init Sortable on timeline ----
const track = document.getElementById('timelineTrack');
Sortable.create(track, {
    animation: 150,
    handle: '.tl-handle',
    filter: '.tl-empty',
    onEnd: recalcTotal
});

// ---- Library filter ----
function filterLib(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#mediaLib .lib-item').forEach(el => {
        el.style.display = el.dataset.name.includes(q) ? '' : 'none';
    });
}

// ---- Drag from library ----
function libDragStart(e) {
    dragSource = 'lib';
    dragData   = e.currentTarget.dataset;
    e.dataTransfer.effectAllowed = 'copy';
}

function trackDragOver(e) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; }

function trackDrop(e) {
    e.preventDefault();
    if (dragSource === 'lib' && dragData) addToTimelineData(dragData);
}

// ---- TL drag (for reorder via custom if needed) ----
function tlDragStart(e) {
    dragSource = 'tl';
}

// ---- Add item ----
function addToTimeline(el) { addToTimelineData(el.dataset); }

function addToTimelineData(d) {
    const empty = document.getElementById('tlEmpty');
    if (empty) empty.remove();

    const dur  = parseFloat(d.duration) || 10;
    const type = d.type;
    const tsrc = d.thumb ? BASE_MEDIA + 'thumbs/' + d.thumb : '';
    const isrc = BASE_MEDIA + 'images/' + d.filename;

    const div = document.createElement('div');
    div.className = 'tl-item new';
    div.dataset.mediaId     = d.id;
    div.dataset.type        = type;
    div.dataset.duration    = dur;
    div.dataset.origDuration = dur;
    div.draggable = true;
    div.addEventListener('dragstart', tlDragStart);
    div.innerHTML = `
        <div class="tl-handle"><i class="fa-solid fa-grip-vertical"></i></div>
        <div class="tl-thumb">
            ${type==='video'
              ? (tsrc ? `<img src="${escHtml(tsrc)}" alt="">` : `<div class="lib-icon"><i class="fa-solid fa-film"></i></div>`)
              : `<img src="${escHtml(isrc)}" alt="">`}
        </div>
        <div class="tl-info">
            <span class="tl-name">${escHtml(d.nameOrig||d['name-orig']||d.name||'')}</span>
            <span class="badge ${type==='video'?'badge-purple':'badge-blue'}">${type==='video'?'Vídeo':'Imagem'}</span>
        </div>
        <div class="tl-duration">
            <label>Duração (s)</label>
            <input type="number" class="dur-input" min="1" step="0.5" value="${dur}" onchange="updateDuration(this)">
        </div>
        <button class="tl-remove" onclick="removeItem(this)" title="Remover">
            <i class="fa-solid fa-times"></i>
        </button>`;
    track.appendChild(div);
    recalcTotal();
    markDirty();
}

function removeItem(btn) {
    btn.closest('.tl-item').remove();
    if (!track.querySelector('.tl-item')) {
        const d = document.createElement('div');
        d.id = 'tlEmpty';
        d.className = 'tl-empty';
        d.innerHTML = '<i class="fa-solid fa-film"></i><p>Arraste mídias aqui ou dê duplo clique nelas</p>';
        track.appendChild(d);
    }
    recalcTotal();
    markDirty();
}

function updateDuration(input) {
    const item = input.closest('.tl-item');
    item.dataset.duration = input.value;
    recalcTotal();
    markDirty();
}

function clearTimeline() {
    if (!confirm('Limpar toda a timeline?')) return;
    track.innerHTML = '<div id="tlEmpty" class="tl-empty"><i class="fa-solid fa-film"></i><p>Arraste mídias aqui ou dê duplo clique nelas</p></div>';
    recalcTotal();
    markDirty();
}

function recalcTotal() {
    let total = 0;
    document.querySelectorAll('.tl-item').forEach(el => {
        total += parseFloat(el.querySelector('.dur-input')?.value || el.dataset.duration || 0);
    });
    const fmt = formatDur(total);
    const cnt = document.querySelectorAll('.tl-item').length;
    document.getElementById('totalDur').textContent    = fmt;
    document.getElementById('totalDurTl').textContent  = fmt;
    document.getElementById('itemCount').textContent   = cnt;
    document.getElementById('saveBtn').disabled = cnt === 0;
}

function markDirty() {}

function saveTimeline() {
    const items = [];
    document.querySelectorAll('#timelineTrack .tl-item').forEach((el, i) => {
        items.push({
            media_id : parseInt(el.dataset.mediaId),
            position : i,
            duration : parseFloat(el.querySelector('.dur-input')?.value || el.dataset.duration || 0)
        });
    });
    fetch(BASE_URL + '/api/timeline.php', {
        method : 'POST',
        headers: {'Content-Type':'application/json'},
        body   : JSON.stringify({store_id: STORE_ID, items})
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) showToast('✅ Timeline salva!');
        else showToast('❌ Erro: ' + d.error);
    });
}

function formatDur(s) {
    const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sc = Math.floor(s%60);
    if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(sc).padStart(2,'0')}`;
    return `${m}:${String(sc).padStart(2,'0')}`;
}

function escHtml(s) { const d=document.createElement('div');d.textContent=s;return d.innerHTML; }

recalcTotal();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
