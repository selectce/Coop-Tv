// Coop TV — Admin JS v2.1
(function(){
  var t = localStorage.getItem('cooptv_theme') || 'dark';
  _apply(t, false);
})();

function _apply(theme, animate) {
  var html = document.documentElement;
  if (!animate) { html.style.transition='none'; setTimeout(function(){ html.style.transition=''; }, 30); }
  html.setAttribute('data-theme', theme);
  localStorage.setItem('cooptv_theme', theme);
  var iD=document.getElementById('iconDark'),  iL=document.getElementById('iconLight');
  var lg=document.getElementById('siteLogo'),   fv=document.getElementById('fav');
  if (iD) iD.style.display = theme==='dark'  ? '' : 'none';
  if (iL) iL.style.display = theme==='light' ? '' : 'none';
  if (lg && typeof LOGOS!=='undefined') lg.src = LOGOS[theme];
  if (fv && typeof LOGOS!=='undefined') fv.href = (theme==='dark' ? LOGOS.favD : LOGOS.favL) + '?v=' + Date.now();
}

function toggleTheme() {
  var t = document.documentElement.getAttribute('data-theme') || 'dark';
  _apply(t==='dark' ? 'light' : 'dark', true);
}

function showToast(msg, ms) {
  var el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(el._t);
  el._t = setTimeout(function(){ el.classList.add('hidden'); }, ms||3000);
}

document.addEventListener('DOMContentLoaded', function(){
  _apply(localStorage.getItem('cooptv_theme')||'dark', false);
  document.querySelectorAll('.alert').forEach(function(el){
    setTimeout(function(){
      el.style.transition='opacity .5s'; el.style.opacity='0';
      setTimeout(function(){ el.remove(); }, 500);
    }, 4000);
  });
});
