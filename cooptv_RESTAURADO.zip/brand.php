<?php
define('BRAND_NAME',    'Mar de Sonhos');
define('BRAND_TAGLINE', 'Sleepwear — Sistema de Mídia');
define('LOGO_DARK',     'http://mstvplayer.selectce.com.br/Images/ms-logo-branco.png');
define('LOGO_LIGHT',    'http://mstvplayer.selectce.com.br/Images/ms-logo-01.png');
define('ICON_DARK',     'http://mstvplayer.selectce.com.br/Images/simbolo-ms-02.png');
define('ICON_LIGHT',    'http://mstvplayer.selectce.com.br/Images/simbolo-ms-01.png');
define('COOP_LOGO',     'http://mstvplayer.selectce.com.br/Images/coop-01.png');
define('DEV_NAME',      'Coop TV');
define('DEV_URL',       'https://coopdigital.com.br');
